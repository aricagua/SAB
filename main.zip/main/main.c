#include <keypad.h>
#include <stdio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_log.h>
#include <esp_system.h>
#include <driver/gpio.h>
#include <tft.h>

#include "dtmf.h"

#define BUZZER_PIN 17


#define SCREEN_WIDTH 128
#define CHAR_WIDTH 6

void pantalla();
void teclado();

// Define a simple 32x32 bitmap of a cat (you can replace this with a more detailed bitmap)
const unsigned char cat_bitmap[] = {
    0x00, 0x0C, 0x30, 0x00, 0x00, 0x1E, 0x78, 0x00,
    0x00, 0x3F, 0xFC, 0x00, 0x00, 0x7F, 0xFE, 0x00,
    0x00, 0xFF, 0xFF, 0x00, 0x01, 0xFF, 0xFF, 0x80,
    0x03, 0xFF, 0xFF, 0xC0, 0x07, 0xFF, 0xFF, 0xE0,
    0x0F, 0xFF, 0xFF, 0xF0, 0x1F, 0xFF, 0xFF, 0xF8,
    0x3F, 0xFF, 0xFF, 0xFC, 0x3F, 0xFF, 0xFF, 0xFC,
    0x7F, 0xFF, 0xFF, 0xFE, 0x7F, 0xE7, 0xE7, 0xFE,
    0x7F, 0xC3, 0xC3, 0xFE, 0x7F, 0xC3, 0xC3, 0xFE,
    0x7F, 0xE7, 0xE7, 0xFE, 0x7F, 0xFF, 0xFF, 0xFE,
    0x7F, 0xFF, 0xFF, 0xFE, 0x7F, 0xFF, 0xFF, 0xFE,
    0x7F, 0xFF, 0xFF, 0xFE, 0x7F, 0xFF, 0xFF, 0xFE,
    0x7F, 0xFF, 0xFF, 0xFE, 0x3F, 0xFF, 0xFF, 0xFC,
    0x3F, 0xFF, 0xFF, 0xFC, 0x1F, 0xFF, 0xFF, 0xF8,
    0x0F, 0xFF, 0xFF, 0xF0, 0x07, 0xFF, 0xFF, 0xE0,
    0x03, 0xFF, 0xFF, 0xC0, 0x01, 0xFF, 0xFF, 0x80,
    0x00, 0xFF, 0xFF, 0x00, 0x00, 0x7F, 0xFE, 0x00
};



// Function to calculate text length
int text_length(const char* text) {
    int length = 0;
    while (*text != '\0') {
        length++;
        text++;
    }
    return length;
}

// Function to calculate centered position
int16_t get_centered_position(const char* text) {
    int text_width = text_length(text) * CHAR_WIDTH;
    return (SCREEN_WIDTH - text_width) / 2;
}

void app_main() {

xTaskCreate(teclado, "TECLADO", 2048, NULL, 5, NULL);
vTaskDelay(pdMS_TO_TICKS(100));
xTaskCreate(pantalla, "PANTALLA", 4096, NULL, 5, NULL);

}

void teclado(){
        /// keypad pinout
    ///                     R1  R2  R3  R4  C1  C2  C3  C4 
    gpio_num_t keypad[8] = {6, 7, 15, 16, 11, 14, 13, 12};

    //Inicializar el teclado
    esp_err_t init_result = keypad_initalize(keypad);
    if (init_result == ESP_OK) {
        ESP_LOGI("KEYPAD", "El teclado se inicializó correctamente");
    } else {
        ESP_LOGE("KEYPAD", "Algo falló al inicializar el teclado");
        return;
    }

    /// Inicializar los tonos
    init_result = dtmf_init(BUZZER_PIN);
    if (init_result == ESP_OK) {
        ESP_LOGI("DTMF", "DTMF Funciona");
    } else {
        ESP_LOGE("DTMF", "Algo falló con el DTMF");
        return;
    }
    while(true)
    {
        char keypressed = keypad_getkey();  /// gets from key queue
        if(keypressed != '\0')
        {
            ESP_LOGI("KEYPAD", "Pressed key: %c", keypressed);
            dtmf_play_tone(keypressed);
        } else {
            ESP_LOGV("KEYPAD", "No key pressed");
        }

        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}

void pantalla(){

        // Initialize TFT
    TFT_Initialize(20, 21, 48, 45, 47); // Adjust these pins according to your wiring
    TFTfillScreen(ST7735_BLACK);

    // Draw the cat bitmap
    TFTdrawBitmap(48, 64, 32, 32, ST7735_WHITE, ST7735_BLACK, cat_bitmap);

    // Wait for 5 seconds
    vTaskDelay(5000 / portTICK_PERIOD_MS);

    // Clear the screen
    TFTfillScreen(ST7735_BLACK);

    // Set text properties
    TFTFontNum(TFTFont_Default);
    TFTsetTextWrap(true);

    // Calculate position for centered text
    const char* line1 = "BIENVENIDO ADMIN";
    const char* line2 = "CONFIGURE UN PIN";
    int16_t x1 = get_centered_position(line1);
    int16_t x2 = get_centered_position(line2);

    // Draw centered text
    TFTdrawText(x1, 50, (char*)line1, ST7735_WHITE, ST7735_BLACK, 1);
    TFTdrawText(x2, 70, (char*)line2, ST7735_WHITE, ST7735_BLACK, 1);

    // Main loop
    while (1) {
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }

}